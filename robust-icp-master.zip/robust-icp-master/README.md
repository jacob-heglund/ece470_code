robust-icp
==========

Matlab code for robust rigid alignment in 3D